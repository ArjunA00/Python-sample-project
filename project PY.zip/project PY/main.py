# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 22:29:00 2020

@author: USER
"""

import ppp
import ccc
import bbb
t1=0
totalscore=0
#cheobj=['atomic absorption','atomic emission','electron absorption','electron emission']
#cheobj2=['rutherford','marie curie','henri becquerel','enrico fermi']
#phyobj=['Hydrometer','Hygrometer','Lactometer','Barometer']
#phyobj2=['air','water','noise','thermal']
#biobj=['pyruvic acid','glucose','fructose','glycolate']
#biobj2=['capsomere','nucleoid','prion','virion']
#phylist=['objective','descriptive']
#chelist=['objective','descriptive']
#biolist=['objective','descriptive']
sublist=['physics','chemistry','biology']
#p1=['every','action','equal','opposite','reaction']
#p2=['current','flowing','conductor','proportional','potential difference','temperature','physical','conditions','through','unchanged']
#c1=['chemical','bonding','involves','contains','electrostatic','attraction','between','oppositely','charged','ions'] 
#c2=['polymerization','process','forming','higher','molecular','mass','macromolecules','consists','contains','repeating','structural','units','derived','monomers']



#b1=['bacteria','carrying','foreign','gene','bacterial','plasmid','genome','transgenic']

#b2=['gene','therapy','correction','malfunctioning','manipulating','repairing','insertng','required','normal']



       
flag1=2
flag2=3
flag3=4
while(len(sublist)>0):
    
    if(flag1!=6):
        if(len(ppp.phylist)==0): 
            sublist.remove('physics')
            flag1=6
    if(flag2!=7):
        if(len(ccc.chelist)==0):
            sublist.remove('chemistry')
            flag2=7
    if(flag3!=9):
        if(len(bbb.biolist)==0):
            sublist.remove('biology')
            flag3=9
    print()
    print()
    if(len(sublist)==0):
        print("total score is ",totalscore)
        break
    print("subjects included ",len(sublist))
    for i in range(0,len(sublist)):    
        print(i,sublist[i])
    print("press 9 to exit")
    id=int(input("select subject id"))
    if(id==9):
        print("Application closing")
        print("totalscore=",totalscore)
        break
    if(sublist[id]=='physics'):
        totalscore=totalscore + ppp.physics()
    elif(sublist[id]=='chemistry'):
        totalscore=totalscore + ccc.chemistry()
    elif(sublist[id]=='biology'):
        totalscore=totalscore + bbb.biology()
    
       
