# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 22:28:55 2020

@author: USER
"""
import support

#totalscore=0
#cheobj=['atomic absorption','atomic emission','electron absorption','electron emission']
#cheobj2=['rutherford','marie curie','henri becquerel','enrico fermi']
phyobj=['Hydrometer','Hygrometer','Lactometer','Barometer']
phyobj2=['air','water','noise','thermal']
#biobj=['pyruvic acid','glucose','fructose','glycolate']
#biobj2=['capsomere','nucleoid','prion','virion']
phylist=['objective','descriptive']
#chelist=['objective','descriptive']
#biolist=['objective','descriptive']
#sublist=['physics','chemistry','biology']
#p1=['every','action','equal','opposite','reaction']
#p2=['current','flowing','conductor','proportional','potential difference','temperature','physical','conditions','through','unchanged']
#c1=['chemical','bonding','involves','contains','electrostatic','attraction','between','oppositely','charged','ions'] 
#c2=['polymerization','process','forming','higher','molecular','mass','macromolecules','consists','contains','repeating','structural','units','derived','monomers']



#b1=['bacteria','carrying','foreign','gene','bacterial','plasmid','genome','transgenic']

#b2=['gene','therapy','correction','malfunctioning','manipulating','repairing','insertng','required','normal']


def physics():
    for i1 in range(0,len(phylist)):
        print(i1,phylist[i1])
    id1 = int(input("select question type"))
    print()
    print()
    
    if(phylist[id1]=='objective'):
        print(" find the instrument that measures and records relative humidity of air ")
        for i2 in range(0,4):
            print(i2,phyobj[i2])
        k=int(input("enter the answer"))
        if(phyobj[k]=='Hygrometer'):
            t1=1
        print("electrostatic precipitator is used to control the pollution of ")
        for i3 in range(0,4):
            print(i3,phyobj2[i3])
        k1=int(input("enter the answer"))
        if(phyobj2[k1]=='air'):
            t1=t1+1
        phylist.remove('objective')
        return t1
    if(phylist[id1]=='descriptive'):
        print("state newtons 3rd law of motion")
        a1=input()
        pk=support.sepp1(a1)
        print("state OHMS LAW")
        a2=input()
        pk=pk+support.sepp2(a2)
        phylist.remove('descriptive')
        return pk
