# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 22:28:56 2020

@author: USER
"""
import support
#t1=0
#totalscore=0
#cheobj=['atomic absorption','atomic emission','electron absorption','electron emission']
#cheobj2=['rutherford','marie curie','henri becquerel','enrico fermi']
#phyobj=['Hydrometer','Hygrometer','Lactometer','Barometer']
#phyobj2=['air','water','noise','thermal']
biobj=['pyruvic acid','glucose','fructose','glycolate']
biobj2=['capsomere','nucleoid','prion','virion']
#phylist=['objective','descriptive']
#chelist=['objective','descriptive']
biolist=['objective','descriptive']
#sublist=['physics','chemistry','biology']
#p1=['every','action','equal','opposite','reaction']
#p2=['current','flowing','conductor','proportional','potential difference','temperature','physical','conditions','through','unchanged']
#c1=['chemical','bonding','involves','contains','electrostatic','attraction','between','oppositely','charged','ions'] 
#c2=['polymerization','process','forming','higher','molecular','mass','macromolecules','consists','contains','repeating','structural','units','derived','monomers']



#b1=['bacteria','carrying','foreign','gene','bacterial','plasmid','genome','transgenic']

#b2=['gene','therapy','correction','malfunctioning','manipulating','repairing','insertng','required','normal']

def biology():
    for i1 in range(0,len(biolist)):
        print(i1,biolist[i1])
    id1 = int(input("select question type"))
    print()
    print()
    
    if(biolist[id1]=='objective'):
        print("What is the substrate of photo-respiration  ")
        for i2 in range(0,4):
            print(i2,biobj[i2])
        k=int(input("enter the answer"))
        if(biobj[k]=='pyruvic acid'):
            t1=1
        
        print("the virus without capsid but only with nucleic acids is called")
        for i3 in range(0,4):
            print(i3,biobj2[i3])
        k1=int(input("enter the answer"))
        if(biobj2[k1]=='nucleoid'):
            t1=t1+1
    
        biolist.remove('objective')
        return t1
    if(biolist[id1]=='descriptive'):
        print("what is transgenic bacteria")
        a1=input()
        pk=support.sepb1(a1)
        print("what is gene therapy")
        a2=input()
        pk=pk+support.sepb2(a2)
        biolist.remove('descriptive')
        return pk
