# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 22:40:44 2020

@author: USER
"""
#t1=0
#totalscore=0
#cheobj=['atomic absorption','atomic emission','electron absorption','electron emission']
#cheobj2=['rutherford','marie curie','henri becquerel','enrico fermi']
#phyobj=['Hydrometer','Hygrometer','Lactometer','Barometer']
#phyobj2=['air','water','noise','thermal']
#biobj=['pyruvic acid','glucose','fructose','glycolate']
#biobj2=['capsomere','nucleoid','prion','virion']
#phylist=['objective','descriptive']
#chelist=['objective','descriptive']
#biolist=['objective','descriptive']
#sublist=['physics','chemistry','biology']
p1=['every','action','equal','opposite','reaction']
p2=['current','flowing','conductor','proportional','potential difference','temperature','physical','conditions','through','unchanged']
c1=['chemical','bonding','involves','contains','electrostatic','attraction','between','oppositely','charged','ions'] 
c2=['polymerization','process','forming','higher','molecular','mass','macromolecules','consists','contains','repeating','structural','units','derived','monomers']



b1=['bacteria','carrying','foreign','gene','bacterial','plasmid','genome','transgenic']

b2=['gene','therapy','correction','malfunctioning','manipulating','repairing','insertng','required','normal']



def sepp1(a):
    k=0
    for i in range(0,len(p1)):
        if(a.find(p1[i],0)==-1):
            continue
        else:
            k+=1
        
    return k
def sepp2(a):
    k=0
    for i in range(0,len(p2)):
        if(a.find(p2[i],0)==-1):
            continue
        else:
            k+=1
        
    return k
def sepc1(a):
    k=0
    for i in range(0,len(c1)):
        if(a.find(c1[i],0)==-1):
            continue
        else:
            k+=1
            
        
    return k

def sepc2(a):
    k=0
    for i in range(0,len(c2)):
        if(a.find(c2[i],0)==-1):
            continue
        else:
            k+=1        
        
    return k

def sepb1(a):
    k=0
    for i in range(0,len(b1)):
        if(a.find(b1[i],0)==-1):
            continue
        else:
            k+=1        
        
    return k
   
def sepb2(a):
    k=0
    for i in range(0,len(b2)):
        if(a.find(b2[i],0)==-1):
            continue
        else:
            k+=1        
        
    return k

